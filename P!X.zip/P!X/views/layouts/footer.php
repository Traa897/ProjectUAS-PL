<footer class="footer">
        <p>&copy; 2025 P!X - Movie Database System</p>
        <p>Develop Patra Ananda 10241061</p>
    </footer>
</body>
</html>